#include<stdio.h>

int main()
{
	int i=0;
	while(1)
	{
		printf("%d\n", i++);
		sleep(2);
	}
}
