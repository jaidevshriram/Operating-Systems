void initialize_history();
void add_history(char *command);
int history(char **tokenized_input, int count);