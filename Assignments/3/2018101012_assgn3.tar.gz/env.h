int set_env(char **tokenized_input, int count);
int unset_env(char **tokenized_input, int count);