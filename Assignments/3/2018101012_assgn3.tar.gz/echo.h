int echo(char *command);
char *formattedecho(char *string);