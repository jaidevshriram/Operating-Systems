void catch_ctrl_c(int temp);
void initialize_signal_handlers();
void set_shell_pid();
void set_child_pid(int child_pid);