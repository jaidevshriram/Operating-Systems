# Assignment 1 - 2018101012

## Question - 1

Input Format: `./a.out <file to be reversed>`
Compiling: `gcc 1.c -lm`
-lm flag is required due to usage of math.h. function

## Question -2

Input Format: `./a.out newfile oldfile directory`
Compiling: `gcc 2.c -lm`